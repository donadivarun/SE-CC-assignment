//updatebooking.php
//updatemedia.php
//updateticker.php
//delete.php