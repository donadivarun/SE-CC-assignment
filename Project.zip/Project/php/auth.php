<?php
    ini_set('session.gc_maxlifetime', 3600);
	//Create connection
	$con=mysqli_connect("localhost","root","","ekbooking");
	date_default_timezone_set('Asia/Dubai');

	//Fetch variables from the URL
	$username = $_POST["username"];
	$password = $_POST["password"];
	
	//Check connection
	if (mysqli_connect_errno()){
  		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
	$sql = "SELECT username,password FROM user_profile;";
    
	if ($result = mysqli_query($con, $sql))
		{
			while($row = mysqli_fetch_assoc($result))
				{ 
                    
	    			if($row['password']==$password && $row['username']==$username)
	    				{
                            session_start();
                            $_SESSION['Login']=$username;
							if(mysqli_query($con,"insert into signin_log values('".$_SESSION['Login']."','".date('Y-m-d H:i:s')."')")){
								header("Location: ../home.php");
							}
	    					
	    				}
                    else
                    	{
                        session_start();
						$_SESSION['Message']="Login Unsuccessful";
                        header("Location: ../index.php");
                         
                    	}
	    		}
            mysqli_free_result($result);
		}
    else
    {
        echo "Username invalid. Please enter a valid username";
    }
	
	mysqli_close($con);
?>