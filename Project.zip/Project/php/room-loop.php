<!DOCTYPE html>
<?php 
    
    $con=mysqli_connect("localhost","root","","ekbooking") or die(mysqli_error());    //Connect to the database
   
    //echo $sql;
    //echo $r_name,$r_id,$capacity; //For debugging purposes
for($r_name=501;$r_name<533;$r_name++){
     $sql="INSERT INTO `rooms`(`r_name`, `capacity`, `Projector`, `PC`, `DVD`, `Video_Conferencing`, `status`, `floor`, `Block`) VALUES ('$r_name',1,0,0,0,0,0,5,'D')"; //SQL query to insert into the rooms table.
    if(mysqli_query($con,$sql)){
        echo "success!";
        
    }
    
    else{
        echo "Room could not be added. Please try again later."+mysqli_error($con);
    }
}
    mysqli_close($con);

?>
