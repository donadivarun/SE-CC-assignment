<?php

    session_start();
    if(!isset($_SESSION['Login']))
    {
        header('Location: index.php');
    }
    else
    {
       
    
    

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<?php

 
$con=mysqli_connect("localhost","root","","ekbooking");
  
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$name=$_GET['m_id'];
if($res=mysqli_query($con,"select r_id from booking where m_id=$name")){
	while($row=mysqli_fetch_assoc($res)){
		$r_id=$row['r_id'];
	}
	echo $r_id;
	mysqli_query($con,"update rooms set status=0 where r_id=$r_id");
}
		
 
$sql = "DELETE FROM booking WHERE m_id='$name';";
//$del_sql="update rooms set status=0 where r_id=$r_id";
 
if ($result = mysqli_query($con, $sql))
{
    echo "Booking deleted!";
   header('Location:book_log.php?m_id='.$name.'&type=delete'); 

}
 
mysqli_close($con);
    }
?>