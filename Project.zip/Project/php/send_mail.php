<?php



use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


require_once "../vendor/autoload.php";
$m_id=$_GET['m_id'];
$con=mysqli_connect("localhost","root","","ekbooking"); 
$sql="select b.s_name, b.r_id, b.date, b.s_time,r.r_name, b.email from booking b,rooms r where b.m_id = '$m_id' and r.r_id=b.r_id;";
$result = mysqli_query($con, $sql);
   //echo $m_id;

if(mysqli_num_rows($result) > 0){
                //echo $m_id;
                    while($row = mysqli_fetch_assoc($result))
                         {
                            $tempArray = $row;
                       //     array_push($resultArray, $tempArray);

                
                        $name=$row['s_name'];
                        $room=$row['r_id'];
                        $date=$row['date'];
                        $stime=$row['s_time'];
                        $email=$row['email'];
                        $r_name=$row['r_name'];
                       // echo "trshtdydjy";
                    }
					$emailarr=explode(",",$email);
                        
                    
                    $message="Greetings '$name', <br /><br /><br />\r\n".
                        "You have successfully booked a meeting for the date '$date' at \r\n".
                        "'".substr($stime,11,5)."'.<br />Your room name for the meeting is '$r_name' <br />\r\n".
                        "Hope u have a great time! <br /><br /><br />\r\n".
                        "Regards, <br />\r\n".
                        "Nikkita Singh,<br />\r\n".
                        "Triway Technologies";
                    
                 //   echo $message, $email;
                
                    
                    
                    
                }
mysqli_close($con);


$mail = new PHPMailer;

//Enable SMTP debugging. 
$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "mail.triwaytechnologies.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "nikkita@triwaytechnologies.com";                 
$mail->Password = "ttech@1234";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "ssl";                           
//Set TCP port to connect to 
$mail->Port = 465;                                   

$mail->From = "nikkita@triwaytechnologies.com";
$mail->FromName = "Nikkita Singh";

foreach($emailarr as $earr){
	$mail->addAddress($earr, $name);
}

$mail->isHTML(true);

$mail->Subject = "Automatic mail";
$mail->Body = $message;
//$mail->AltBody = "what goes over here?";
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);

	header("Location:../home.php#success");



if(!$mail->send()) 
{
    echo "Mailer Error: " . $mail->ErrorInfo;
} 
else 
{
    echo "Message has been sent successfully";
}












/*

if($result = mysqli_query($con,$mail_query)){
                echo $meeting_name;
                    while($row = mysqli_fetch_assoc($result))
                         {
                            $tempArray = $row;
                       //     array_push($resultArray, $tempArray);

                
                        $name=$row['s_name'];
                        $room=$row['r_id'];
                        $date=$row['date'];
                        $stime=$row['s_time'];
                        $email=$row['email'];
                        echo "trshtdydjy";
                    }
                        
                    
                    $message="Greetings '$name', \r\n".
                        "You have successfully booked a meeting for the date '$date' at \r\n".
                        "'$stime'. your room number for the meeting is '$room' \r\n".
                        "Hope u have a great time! \r\n".
                        "Good bye idiots";
                    
                    echo $message, $email;
                
                    
                    
                    
                }
                
                
                */
?>