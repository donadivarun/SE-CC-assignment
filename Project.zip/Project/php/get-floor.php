<?php 
    
    $con=mysqli_connect("localhost","root","","ekbooking") or die(mysqli_error());    //Connect to the database
   
    //echo $sql;
    //echo $r_name,$r_id,$capacity; //For debugging purposes
 
        $sql="select distinct(floor) from rooms"; //SQL query to insert into the rooms table.
        $arr=array();
    if($res=mysqli_query($con,$sql)){
        while($row=mysqli_fetch_assoc($res)){
            array_push($arr,$row['floor']);    
        }
    }   
    else{
        echo "floors could not be fetched please try agian later.";
    }
    
    echo json_encode($arr);
    mysqli_close($con);

?>