<?php //start php code.
    
         $con=mysqli_connect("localhost","root","","ekbooking"); //Connect to the mySQL server.
    if (mysqli_connect_errno()) //Check if its connected or not.
        { 
            echo "Failed to connect to MySQL: " . mysqli_connect_error(); //If unable to connect, display error.
        }
    $get_room_id="select r_id,r_name from rooms order by capacity;"; // SQL query to get room id from the database.
    $room_id=array();
    $room_name=array();             // An array to store all the room numbers.
    $result=mysqli_query($con,$get_room_id); //Execute the query.
    if(mysqli_num_rows($result) > 0){ // check if the query returned any rows, if yes then proceed:
        //echo "Get room number successful!"; //For debugging purposes.
        while($row = mysqli_fetch_assoc($result)){ //if there are more than 1 rows, then an array to read data one by one from the result.
            $room_id[]=$row['r_id'];  // for storing the room ids in the $room_id array.
            $room_name[]=$row['r_name'];
        }
        
        
    }
    
    // uncomment the following lines to check if the room numbers are being called correctly.
    
    /*foreach($room_id as $room_no){
        echo "\n room number : ".$room_no;
    }*/
    $today=date("Y/m/d");
    
    
    $meeting_detail = array(); // for storing all the details of meetings that are going to take place in a room
    
    foreach($room_id as $room_no){
        $get_meetings="select m_id,m_name,s_time,e_time,s_name from booking where date='$today' and r_id='$room_no';";
        $room_meeting_detail=array();
        $result=mysqli_query($con,$get_meetings);
        $meeting_detail_array=array();
        if(mysqli_num_rows($result) > 0){ // check if the query returned any rows, if yes then proceed:
            
          //  echo "Get Meetings successfully"; //For debugging purposes.
            while($row = mysqli_fetch_assoc($result)){ //if there are more than 1 rows, then an array to read data one by one from the                                                  //result.
                
                //Storing the required details in an array.
                $room_meeting_detail['m_name']=$row['m_name']; 
                $room_meeting_detail['m_id']=$row['m_id'];
                $room_meeting_detail['s_name']=$row['s_name'];        
                $room_meeting_detail['s_time']=$row['s_time'];        
                $room_meeting_detail['e_time']=$row['e_time'];        
                $meeting_detail_array[]=$room_meeting_detail;
            }
        }
        //var_dump($meeting_detail_array);
        $meeting_detail[$room_no]=$meeting_detail_array; //creating a nested array to hold all the meeting deatils according to the room                                                       //numbers in an array.
        //var_dump($room_meeting_detail);
        // clearing and reinitialising the array.
        unset($room_meeting_detail);
        $room_meeting_detail=array();
    }
    //var_dump($meeting_detail); //dumping all the variables to check if the array is proper. For debugging.
    
    //echo sizeof($room_id); //for debugging
    
    
    
    //change the html code here for visuals and stuff
        echo "<div class='container-fluid'>"; //creating a division to hold the table.
        echo "<table class='rooms_table' id='room_table'>"; //creating a table
        $i=0; //row count
        $j=0; //column count
        $col_count=4;//the column size
        $room_count=0;//roomcount
        $more_option=1;//assigns the number of meetings to be displayed on each cell after which the more option appears.
        // Creating the rows and cloumns of the table as per the rooms table in the ekbooking database.
        // to add new rooms dont change anything in this file.
        // just update the rooms table in the database and refresh the page to see the changes.
        while($i<(sizeof($room_id)/$col_count)){ //check for number of rows
            echo "<div class='row' style='margin:10px 0px 0px 0px;'>";
            echo "<tr id='table-layout-inline'>"; //creating a table row
                while($j<$col_count){ //check for number of columns
                    
                    $id=$room_id[$room_count]; //too assign the id of individual room element in the table
                    echo " 
                    <div class='col-lg-3 col-md-6 col-sm-6'>
                    <td id='room_table_data'>
                    <div class='card card-stats'>
                    <div class='card-header success' data-background-color=green id='$id' >
                                    
									<i class='material-icons unselectable' unselectable='on'>group</i>
								</div>
                                
                    <div class='card-content'>
                                    <h2 class='title' style='white-space:nowrap;'><b><a href='#' class='room-table-view' value='".$room_id[$room_count]."'> $room_name[$room_count]</a></b></h2>
                                    <script>
											
                                    </script>
                                   
									
								</div>
                            ";//creating the room cell in the table
                                //echo $room_id[$room_count]; //echoing the room number
                                //echo "<br>"; 
                                $x=0; // this variable is for checking if there are meetings more than the threshhold. if so, show a more 
                                      //option and hide the extra part.
                                $md=$meeting_detail[$room_id[$room_count]];//get all the meeting details for the room
                                //var_dump($md);//for debugging
                                echo "	<div class='card-footer'>
									<div class='stats '>";
                                echo "<i class='material-icons text-success unselectable' id='time-icon-".$room_id[$room_count]."'>schedule</i> ";
                    
										
									            
                                foreach($md as $md1){   
                                    //for displaying all the meeting happening in the room.
                                    echo "<a href='#' class='room-card-footer-view' value='".$md1['m_id']."'>(".substr($md1['s_time'],11,5)." - ".substr($md1['e_time'],11,5).")&nbsp</a>";
                                  //echo "<script></script>";
                                    $x++;
                                    if($x>$more_option){
                                        echo "<a href='#' class='room-table-view' value='".$room_id[$room_count]."'>More</a>"; //if meeting are more than 1 display more then stop.
                                        //make the room warning if the number of meetings are more than 3.
                                        echo "<script>
                        
                                           $('#".$room_id[$room_count]."').attr('data-background-color','orange');
                       
                                            $('#".$room_id[$room_count]."').toggleClass('success');//change the class for success here
                                            $('#".$room_id[$room_count]."').toggleClass('warning'); //change the class for warning here
                                            $('#time-icon-".$room_id[$room_count]."').toggleClass('text-success'); //change the class for time icon here
                                            $('#time-icon-".$room_id[$room_count]."').toggleClass('text-danger'); //change the class for time icon here
                                            
                                            </script>";
                                      
                                        break;
                                    }// close if
                                }// close foreach
                    echo "</div>
								</div>
				                        ";
                    echo "
                        
                        </div>
                        </td>
                        </div>";//closing html tags
                    $j++;//increment column
                    if($room_count<sizeof($room_id)-1){
                        $room_count++; //increment the roomcount
                    }
                    else{
                        break; //if roomcount more than number of rooms, break.
                    }
                }//close inner while
            echo "</tr>";//close html tags
            echo "</div>";
            $i++;//increment row.
            $j=0;//rest coumn to 0.
        }//close outer while
        echo "</table>";//close table
        echo "</div>";//close div
                
        
        //end php.
        ?>