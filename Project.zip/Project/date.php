<?php
echo date('Y-m-d H:i:s');
$con=mysqli_connect("localhost","root","","ekbooking"); //Connect to the mySQL server.
if (mysqli_connect_errno()) //Check if its connected or not.
        { 
            echo "Failed to connect to MySQL: " . mysqli_connect_error(); //If unable to connect, display error.
        }
$sql="select * from booking";
$result=mysqli_query($con,$sql); //Execute the query.
    if(mysqli_num_rows($result) > 0){ // check if the query returned any rows, if yes then proceed:
        //echo "Get room number successful!"; //For debugging purposes.
        while($row = mysqli_fetch_assoc($result)){ //if there are more than 1 rows, then an array to read data one by one from the result.
            
        }
    }
?>