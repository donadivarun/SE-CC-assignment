<!doctype html>
<?php 
    session_start();
    if(!isset($_SESSION['Login']))
    {
        header('Location: index.php');
    }
    else
    {
      // echo "HeY@@!!";
    
    ?>
<html>
<?php

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
date_default_timezone_set('Asia/Dubai');
?>
<head>
  
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>Booking System</title>
    <script src="js/jquery.js" type="text/javascript"></script>  
    <script src="js/jquery-ui.js" type="text/javascript"></script>
    <script src="js/jquery.min.js" type="text/javascript"></script>
  
   <!--    For modal forms     -->


    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />


    <link href="css/vis-timeline-graph2d.min.css" rel="stylesheet" type="text/css" />
    <!--  Material Dashboard CSS    -->
    <link href="css/material-dashboard.css" rel="stylesheet" />
    <link href="css/graph-style.css" rel="stylesheet" />
    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>
    <link href="css/bootstrap.css" rel="stylesheet" /> 
    <link href="css/login-register.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css" />
 
	<!-- jQuery -->
    <link rel="stylesheet" href="css/jquery-ui.css">
  	<link href='css/fullcalendar.min.css' rel='stylesheet' /> <!-- loading the css part of the calendar. -->
    <link href='css/fullcalendar.print.min.css' rel='stylesheet' media='print' />

     
	


      <style>
        .ui-datepicker{
          z-index:11510000000 !important;
        }
        #title {
            margin: 17px 5px 10px 5px;
            font-size: 35px;
            color: black;
        }
        
        #menu {
            margin-left: 500px;
            margin-top: 30px;
        }
        
        .atv,
        .str {
            color: #05AE0E;
        }
        
        .tag,
        .pln,
        .kwd {
            color: #3472F7;
        }
        
        .atn {
            color: #2C93FF;
        }
        
        .pln {
            color: #333;
        }
        
        .com {
            color: #999;
        }
        
        .space-top {
            margin-top: 50px;
        }
        
        .area-line {
            border: 1px solid #999;
            border-left: 0;
            border-right: 0;
            color: #666;
            display: block;
            margin-top: 20px;
            padding: 8px 0;
            text-align: center;
        }
        
        .area-line a {
            color: #666;
        }
        
        .container-fluid {
            padding-right: 15px;
            padding-left: 15px;
        }
        .form-group{
          margin:3px 0 0 0;
        }
		  #script-warning {
            display: none;
            
        }
        
        #loading {
            display: none;
            position: relative;
            top: -20px;
            right: 10px;
        }
        
        #calendar {
            margin: 0 auto;
            max-width: 80%;
            display: block;
            padding: 0 10px;
            align-content: center;
            align-items: center;
           
        
        
    </style>
    
        <style>
        /*
            All the necessary styling for the table of rooms done here!
            The only styling dont in-line html is to check if the room is warning with many meetings or not.
            All the rest 0of the styling is done here
        */
        a{
            /*display: block;
            height: 100px;
            width: 250px;*/
            color:white;
            text-decoration-line: none;
        }
            #addaroom{
                color:dimgrey;
                padding-left: 20px;
                cursor: pointer;
            }
        b{
            font-size: 15px;
        }
            #table-layout-inline{
                display:table;
                width:100%;
                table-layout:fixed;
                
            }
        td{
            
        }
        .meeting_time{
            font-size: 11px;
        }
        .occupied_b{
            background-color: red;
        }
        .occupied_a{
            background-color: red;
        }
            #room_table_data{
				max-width: 300px;
				border-radius: 5px;
				height:auto;
				width:250px; 
				color: white;
				text-align:center;
				cursor: pointer;
                padding: 0 10px 0 10px;
            }
            .rooms_table{
                display: block;
                overflow-y: scroll;
                overflow-x: hidden;
                max-height: 420px;
                width:100%;
            }
            .unselectable {
				-moz-user-select: -moz-none;
				-khtml-user-select: none;
				-webkit-user-select: none;
				-o-user-select: none;
				user-select: none;
}
          #classTable tbody tr td{
            color: #646464;
          }
			input[type=number]::-webkit-inner-spin-button, 
        	input[type=number]::-webkit-outer-spin-button { 
            -webkit-appearance: none;
            
            appearance: none;
            margin: 0; 
        }
       
    
    </style>
        <!-- 
            Note: if u dont have an internet connection, you might want to download these files add them to your woking directory and call them locally.
        -->

        <script>
        $(document).ready(function(){ //Check if the document is loaded or not.
            
            
            $.ajax({
                url: 'php/get-floor.php',
                dataType: 'json',
                type: 'post',
                success: function(floor){
                    //alert(floor);
                    for (var i = 0; i < floor.length; i++){
                        $("#dropdown-floor").append($('<option>', {
                            value: floor[i],
                            text: floor[i]
                        }));
                    }
                }
            });
            $.ajax({
                url: 'php/get-block.php',
                dataType: 'json',
                type: 'post',
                success: function(floor){
                    //alert(floor);
                    for (var i = 0; i < floor.length; i++){
                        $("#dropdown-block").append($('<option>', {
                            value: floor[i],
                            text: floor[i]
                        }));
                    }
                }
            });
            var block='b';
            var floor='1';
            var getUrlParameter = function getUrlParameter(sParam) {
                var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                    sURLVariables = sPageURL.split('&'),
                    sParameterName,
                    i;

                for (i = 0; i < sURLVariables.length; i++) {
                    sParameterName = sURLVariables[i].split('=');

                    if (sParameterName[0] === sParam) {
                        return sParameterName[1] === undefined ? true : sParameterName[1];
                    }
                }
            };
            if(getUrlParameter('block')!=null){
                block=getUrlParameter('block');
                floor=getUrlParameter('floor');
            }
            $('#dropdown-floor [value="'+floor+'"]').attr("selected",true);
            $('#dropdown-block [value="'+block+'"]').attr("selected",true);
            $('#dropdown-floor').change(function(){
               window.location.href="home.php?block="+$("#dropdown-block :selected").text()+"&floor="+$("#dropdown-floor :selected").text(); 
                
            });
             $('#dropdown-block').change(function(){
               window.location.href="home.php?block="+$("#dropdown-block :selected").text()+"&floor="+$("#dropdown-floor :selected").text(); 
                
            });
           
        });//end document and script
			
				
				//alert("xyz");
				
			
			
    </script>
</head>

<body onload="openViewModal2()">
    
    
    

       <?php include('header2.php'); ?> 
    
    
    
    
    
    
    <div class="wrapper">
         
        
        
            <div class="sidebar" data-color="red" data-background="blue" style="position:fixed;">
			<!--
		        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

		        Tip 2: you can also add an image using data-image tag
		    -->

			

	    	<div class="sidebar-wrapper" >
				<ul class="nav">
	                <li> 
                        <a data-toggle="modal" href="javascript:void(0)" onclick="openLoginModal();" style="margin-top:60%;">
                        
                            
                            <i class="material-icons unselectable">event</i>
                            Book a Room 
                        </a>
	                </li>
                     <li>
	                    <a data-toggle="modal" href="javascript:void(0)" onclick="openViewModal();">
                            <i class="material-icons unselectable">edit</i>
                            View/Edit a Booking
                        </a>
	                </li>
					<li>
	                    <a data-toggle="modal" href="javascript:void(0)" onclick="openViewModal3();">
                            <i class="material-icons unselectable">search</i>
                            Filtered Booking search
                        </a>
	                </li>
                    <!--<li>
	                    <a data-toggle="modal" href="javascript:void(0)" onclick="openAddRoom();">
	                        <i class="material-icons unselectable">add box</i>
	                        <p>Add a Room</p>
	                    </a>
	                </li>-->
	                <li>
	                    <a href="user.html">
	                        <i class="material-icons unselectable">person</i>
	                        <p>User Profile</p>
	                    </a>
	                </li>
	               
	              
	                <li>
	                    <a href="icons.html">
	                        <i class="material-icons unselectable">settings</i>
	                        <p>Settings</p>
	                    </a>
	                </li>
                    
                    
	               
	               
	                
	            </ul>
	    	</div>
		</div>
        
        
        
        
        
        
        
        
        
        <div class="modal fade login" id="loginModal">
      <div class="modal-dialog login animated">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title">Add a booking</h4>
          </div>
          <div class="modal-body">  
            <div class="box">
              <div class="content">  
                <div class="form loginBox">
                  <form method="POST" accept-charset="UTF-8" action="php/add_booking.php" id="addabooking">
                    <div class="row">
                    <div class="col-md-8">
                    <div class="form-group label-floating">
		              <label class="control-label">Booking Name</label>
                      <input type="text" class="form-control" name="m_name" required>
                    </div>
                      </div>
                    <div class="col-md-4">
                    <div class="form-group label-floating">
		              <label class="control-label" id="nogtog">Number of Guests</label>    
                      <input type="number" class="form-control" name="guests" required>
                    </div>
                      </div>
                    </div>
                    <div class="row">
                    <div class="col-md-6">
                    <div class="form-group label-floating">
		              <label class="control-label">Staff Name</label>
                      <input type="text" class="form-control" name="s_name" required>
                    </div>
                      </div>
                      <div class="col-md-6">
                    <div class="form-group label-floating">
		              <label class="control-label">Staff ID</label>
                      <input type="text" class="form-control" name="s_id" required>
                    </div>   
                      </div>
                    </div>
                    <div class="form-group">
                      
		              <label class="control-label">Date</label>
                      <input type="text" class="form-control" id='datetimepicker4' name="date" required>          
                      <script type="text/javascript">
                              //$('.datepicker').datepicker({
                              //weekStart:1
                              //});
                        $(function () {
                          $('#datetimepicker4').datetimepicker({
                            format: 'YYYY-MM-DD'
                          });
                        });
                      </script>   
                    </div>              
                    <div class="row">
                    <div class="col-md-6">
                    <div class="form-group">
		              <label class="control-label">Start Time</label>
                      <input type='text' class="form-control" id='datetimepicker1' name="s_time" required />                    
                      <script type="text/javascript">
                        $(function () {
                          $('#datetimepicker1').datetimepicker({
                            format: 'HH:mm:ss'
                          });
                        });
                      </script>                
                    </div>
                       </div>
                    <div class="col-md-6">
                    <div class="form-group">
                      <label class="control-label">End Time</label>
                      <input type='text' class="form-control" id='datetimepicker2' name="e_time" required />                 
                      <script type="text/javascript">
                        $(function () {
                          $('#datetimepicker2').datetimepicker({
                            format: 'HH:mm:ss'
                          });
                        });
                      </script>
                    </div>
                       </div>
                    </div>
                    <br>                    
                    <div class="checkbox">
                      <label>
                          <input type="checkbox" name="tel"  value="telephone">
                          Telephone
                      </label>
                      <label style="position:fixed; left:50%;">
                          <input type="checkbox" name="tv" >
                          TV
                      </label>
                  </div>
                  <div class="checkbox">
                      <label>
                          <input type="checkbox" name="projector">
                          Projector
                      </label>
                      <label style="position:fixed; left:50%;">
                          <input type="checkbox" name="pc">
                          PC
                      </label>
                  </div><div class="checkbox">
                      <label>
                          <input type="checkbox" name="ip"  >
                          IP-Board
                      </label>
                      <label style="position:fixed; left:50%;">
                          <input type="checkbox" name="dvd"  >
                          DVD
                      </label>
                  </div><div class="checkbox">
                      <label>
                          <input type="checkbox" name="podium"  >
                          Podium-Microphone
                      </label>
                      <label style="position:fixed; left:50%;">
                          <input type="checkbox" name="cordless" >
                          Cordless-Microphone
                      </label>
                  </div><div class="checkbox">
                      <label>
                          <input type="checkbox" name="lap" >
                          Lap-Microphone
                      </label>
                      <label style="position:fixed; left:50%;">
                          <input type="checkbox" name="vc"  >
                          Video-Conferencing
                      </label>
                  </div>
                    
                    <div class="row">
                    <div class="col-md-4">
                    <div class="form-group label-floating">
		              <label class="control-label">Contact</label>
                      <input type="number" class="form-control" name="contact" required>
                      </div>
                      </div>
                    <div class="col-md-8">
                    <div class="form-group label-floating">
		              <label class="control-label">E-Mail</label>
                      <input id="email" class="form-control" type="text" name="email">
                    </div>
                      </div>
                    </div>
                    <button class="btn btn-default btn-login" value="Add a booking" >Add a booking</button>
                  </form>
                </div>
              </div>
            </div>      
          </div>      
        </div>
      </div>
    </div>
        
       
        <div class="modal fade login" id="loginModal2">
      <div class="modal-dialog login animated">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title">Add a booking</h4>
          </div>
          <div class="modal-body">  
            <div class="box">
              <div class="content">  
                <div class="form loginBox2">
                  <form method="POST" accept-charset="UTF-8" action="php/add_booking.php" id="addabooking2">
                    <div class="row">
                    <div class="col-md-8">
                    <div class="form-group label-floating">
		              <label class="control-label">booking Name</label>
                      <input type="text" class="form-control" name="m_name" required>
                    </div>
                      </div>
                    <div class="col-md-4">
                    <div class="form-group label-floating">
		              <label class="control-label" id="nogtog">Number of Guests</label>    
                      <input type="number" class="form-control" name="guests" required>
                    </div>
                      </div>
                    </div>
                    <div class="row">
                    <div class="col-md-6">
                    <div class="form-group label-floating">
		              <label class="control-label">Staff Name</label>
                      <input type="text" class="form-control" name="s_name">
                    </div>
                      </div>
                      <div class="col-md-6">
                    <div class="form-group label-floating">
		              <label class="control-label">Staff ID</label>
                      <input type="text" class="form-control" name="s_id">
                    </div>   
                      </div>
                    </div>
                    <div class="form-group">
                      
		              <label class="control-label">Date</label>
                      <input type="text" class="form-control" id='datetimepicker4' name="date" required>          
                      <script type="text/javascript">
                              //$('.datepicker').datepicker({
                              //weekStart:1
                              //});
                        $(function () {
                          $('#datetimepicker4').datetimepicker({
                            format: 'YYYY-MM-DD'
                          });
                        });
                      </script>   
                    </div>              
                    <div class="row">
                    <div class="col-md-6">
                    <div class="form-group">
		              <label class="control-label">Start Time</label>
                      <input type='text' class="form-control" id='datetimepicker1' name="s_time" required />                    
                      <script type="text/javascript">
                        $(function () {
                          $('#datetimepicker1').datetimepicker({
                            format: 'HH:mm:ss'
                          });
                        });
                      </script>                
                    </div>
                       </div>
                    <div class="col-md-6">
                    <div class="form-group">
                      <label class="control-label">End Time</label>
                      <input type='text' class="form-control" id='datetimepicker2' name="e_time" required />                 
                      <script type="text/javascript">
                        $(function () {
                          $('#datetimepicker2').datetimepicker({
                            format: 'HH:mm:ss'
                          });
                        });
                      </script>
                    </div>
                       </div>
                    </div>
                    <br>                    
                    
                    <input type="hidden" name="r_id" id="r_id_room_booking" value="" />
                    <div class="row">
                    <div class="col-md-4">
                    <div class="form-group label-floating">
		              <label class="control-label">Contact</label>
                      <input type="number" class="form-control" name="contact" required>
                      </div>
                      </div>
                    <div class="col-md-8">
                    <div class="form-group label-floating">
		              <label class="control-label">E-Mail</label>
                      <input id="email" class="form-control" type="text" name="email">
                    </div>
                      </div>
                    </div>
                    <button class="btn btn-default btn-login" value="Add a booking" >Add a Booking</button>
                  </form>
                </div>
              </div>
            </div>      
          </div>      
        </div>
      </div>
    </div>
            
        
         <div class="modal fade view" id="viewModal">
		      <div class="modal-dialog login animated">
    		      <div class="modal-content">
    		         <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">View a booking</h4>
                    </div>
                    <div class="modal-body">  
                        <div class="box">
                             <div class="content">
                                <div class="form viewBox" id="testforenter">
                                    <form accept-charset="UTF-8" onclick="return false;">
                                    <input type="number" class="form-control" placeholder="Booking ID" name="m_id" id="meetingid" required>
                                    
                                    <input class="btn btn-default btn-login" id="view-button" type="submit" value="View a Booking" onclick="getMeeting()">
                                    </form>
                                  <script>
                                     
                                        
                                        </script>
                                </div>
                             </div>
                        </div>
                        
                    </div>
                      
    		      </div>
		      </div>
		  </div>
        
        
        
		
		
		<div class="modal fade view" id="viewModal3">
		      <div class="modal-dialog login animated">
    		      <div class="modal-content">
    		         <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">View a booking</h4>
                    </div>
                    <div class="modal-body" id="filterMeetings">  
                        
            			
                        
                    </div>
                      
    		      </div>
		      </div>
		  </div>
		
		
		<div class="modal fade view" id="viewModal4">
		      <div class="modal-dialog login animated">
    		      <div class="modal-content">
    		         <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">View a booking</h4>
                    </div>
                    <div class="modal-body" id="viewMeetingsByDate">  
                        
            			
                        
                    </div>
                      
    		      </div>
		      </div>
		  </div>
        
       
        
<div class="modal fade view" id="viewModal2" >
  <div class="modal-dialog login animated">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">View a booking</h4>
      </div>
      <div class="modal-body" id="view-edit-modal-body">  
        <script>
        </script>        
      </div>        
    </div>
  </div>
</div>
      
        <div class="modal fade login" id="addRoom">
		      <div class="modal-dialog login animated">
    		      <div class="modal-content">
    		         <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Add a Room</h4>
                    </div>
                    <div class="modal-body">  
                        <div class="box">
                             <div class="content">
                                 <div class="form addRoom">
                                
                        <form method="post" action="" accept-charset="UTF-8">
   
                            <input type="text" class="form-control" placeholder="Enter Room ID" name="r_id" id="rid" required>
                                    <input type="text" class="form-control" placeholder=" Enter Room Name" name="r_name" id='rname' required>
                                    <input type="text" class="form-control" placeholder="Enter Room Capacity" name="capacity" id='capacity' required>
                                    <input class="btn btn-default btn-login" type="button" value="Submit" onclick="addRoom()">
                                    </form>
                          </div>
                        </div>
                      </div>
                    </div>      
                  </div>    
    		    </div>
		      </div>
		    
      <div class="main-panel">
        
               <div class="content">
				   <p id='server-date' style="color:#646464; margin-top:60px; font-size:30px; font-family:helvetica;">
				   </p>
                 
                <p id="date" style="color:#646464; margin-top:60px; font-size:30px; font-family:helvetica;"> 
                     
                     <script type="text/javascript">
                          var m_names = ["January", "February", "March", 
                          "April", "May", "June", "July", "August", "September", 
                          "October", "November", "December"];

                          var d_names = ["Sunday","Monday", "Tuesday", "Wednesday", 
                          "Thursday", "Friday", "Saturday"];

                          var myDate = new Date();
                          myDate.setDate(myDate.getDate());
                          var curr_date = myDate.getDate();
                          var curr_month = myDate.getMonth();
                          var curr_day  = myDate.getDay();
                          document.write(d_names[curr_day] + ","  + m_names[curr_month] + " " +curr_date);
                     </script>
                 
                 </p>
                   
                    <select id="dropdown-block">
                       
                    </select>
                    <select id="dropdown-floor">
                        
                    </select>
                   


                  <ul class="nav nav-pills nav-pills-danger" role="tablist" style="margin-top:0px; float:right; margin-right:20px;">
                      <li class="active">
                                  <a href="#" role="tab" id="gridtab">
                                      Grid View
                                  </a>
                      </li>
                    <li class="active">
                                  <a href="#" role="tab" id="calendartab">
                                      Calendar View
                                  </a>
                      </li>
                  </ul>
				   <script>
				   
					   $(function(){
						   $('#graphtab').click(function(){
							   $('#grid-tab').addClass('hidden');
							   $('#graph-tab').removeClass('hidden');
							   $.ajax({
								  url: 'php/vis-js-json.php'
							   });
							   $('#graph-tab').load('graph.php');
						   });
					   $('#gridtab').click(function(){
							   $('#graph-tab').addClass('hidden');
							   $('#grid-tab').removeClass('hidden');
							   
						   });
					   
					   $('#calendartab').click(function(){
						   if(!$('#graph-tab').hasClass('hidden')){
							   $('#graph-tab').addClass('hidden');
						   }
						   if(!$('#grid-tab').hasClass('hidden')){
							   $('#grid-tab').addClass('hidden');
						   }
						   $('#calendar-tab').removeClass('hidden');
						   $('#calendar').fullCalendar({
								header: {
									left: 'prev,next today',
									center: 'title',
									right: 'month,agendaWeek,agendaDay,listWeek'
								},
								defaultDate: new Date(),
								editable: false, // allows resizing and dragging of the events in the interactive calendar.
								navLinks: true, // can click day/week names to navigate views
								eventLimit: true, // allow 'more' link when too many events
								events: {
									url: 'php/get-events.php', //get the events stored in the json file and displays on the interactive calendar.
									error: function() { 
										$('#script-warning').show(); //error if the server is not working.
									}
								},
								loading: function(bool) {
									$('#loading').toggle(bool); //loading of the interactive calendar.
								},

								eventClick: function(event,jsEvent,view) {
									if(event.m_id) {
										// $('#view-meeting').toggle(); //show the display for 'edit a meeting' sidebar.
										$('#meetingid').val(event.m_id);
										$('#view-button').click();
										// var link = 'home.php?m_id=' + event.m_id; //the link that is to be called again.
										// delete the above link and use a local variable to pass the variable m_name. easier and quicker solution.
										// window.location.href = link; 
										// for the edit part, store the link in a variable in jquery and call it in php so there is no need to load a page again!
										//$('#add-meeting').toggle(); //hide the display for the 'add a booking' side-bar
										return false;
						   }

							},
									eventColor:'rgba(200,0,0)' //change the color for the events on the calendar!
							});
						   		
							   
						   });
					   });
				   
				   </script>
                         
    <div id="grid-tab">                   
     <label class="hidden" id="meeting_id_modal" val=""></label>
     <label class="hidden" id="room_id_modal" val=""></label>
     <?php //start php code.
        $block='B';
        $floor=1;
        if(isset($_GET['block'])){
            $block=$_GET['block'];
        }
        if(isset($_GET['floor'])){
            $floor=$_GET['floor'];
        }

    
         $con=mysqli_connect("localhost","root","","ekbooking"); //Connect to the mySQL server.
    if (mysqli_connect_errno()) //Check if its connected or not.
        { 
            echo "Failed to connect to MySQL: " . mysqli_connect_error(); //If unable to connect, display error.
        }
    $get_room_id="select r_id,r_name from rooms where block='$block' and floor='$floor' order by capacity;"; // SQL query to get room id from the database.
    $room_id=array();
    $room_name=array();             // An array to store all the room numbers.
    $result=mysqli_query($con,$get_room_id); //Execute the query.
    if(mysqli_num_rows($result) > 0){ // check if the query returned any rows, if yes then proceed:
        //echo "Get room number successful!"; //For debugging purposes.
        while($row = mysqli_fetch_assoc($result)){ //if there are more than 1 rows, then an array to read data one by one from the result.
            $room_id[]=$row['r_id'];  // for storing the room ids in the $room_id array.
            $room_name[]=$row['r_name'];
        }
        
        
    }
    
    // uncomment the following lines to check if the room numbers are being called correctly.
    
    /*foreach($room_id as $room_no){
        echo "\n room number : ".$room_no;
    }*/
    $today=date("Y/m/d");
    
    
    $meeting_detail = array(); // for storing all the details of meetings that are going to take place in a room
    
    foreach($room_id as $room_no){
        $get_meetings="select m_id,m_name,s_time,e_time,s_name from booking where date='$today' and r_id='$room_no';";
        $room_meeting_detail=array();
        $result=mysqli_query($con,$get_meetings);
        $meeting_detail_array=array();
        if(mysqli_num_rows($result) > 0){ // check if the query returned any rows, if yes then proceed:
            
          //  echo "Get Meetings successfully"; //For debugging purposes.
            while($row = mysqli_fetch_assoc($result)){ //if there are more than 1 rows, then an array to read data one by one from the                                                  //result.
                
                //Storing the required details in an array.
                $room_meeting_detail['m_name']=$row['m_name']; 
                $room_meeting_detail['m_id']=$row['m_id'];
                $room_meeting_detail['s_name']=$row['s_name'];        
                $room_meeting_detail['s_time']=$row['s_time'];        
                $room_meeting_detail['e_time']=$row['e_time'];        
                $meeting_detail_array[]=$room_meeting_detail;
            }
        }
        //var_dump($meeting_detail_array);
        $meeting_detail[$room_no]=$meeting_detail_array; //creating a nested array to hold all the meeting deatils according to the room                                                       //numbers in an array.
        //var_dump($room_meeting_detail);
        // clearing and reinitialising the array.
        unset($room_meeting_detail);
        $room_meeting_detail=array();
    }
    //var_dump($meeting_detail); //dumping all the variables to check if the array is proper. For debugging.
    
    //echo sizeof($room_id); //for debugging
    
    
    
    //change the html code here for visuals and stuff
        echo "<div class='container-fluid'>"; //creating a division to hold the table.
        echo "<table class='rooms_table' id='room_table'>"; //creating a table
        $i=0; //row count
        $j=0; //column count
        $col_count=4;//the column size
        $room_count=0;//roomcount
        $more_option=1;//assigns the number of meetings to be displayed on each cell after which the more option appears.
        // Creating the rows and cloumns of the table as per the rooms table in the ekbooking database.
        // to add new rooms dont change anything in this file.
        // just update the rooms table in the database and refresh the page to see the changes.
        while($i<(sizeof($room_id)/$col_count)){ //check for number of rows
            echo "<div class='row' style='margin:10px 0px 0px 0px;'>";
            echo "<tr id='table-layout-inline'>"; //creating a table row
                while($j<$col_count){ //check for number of columns
                    
                    $id=$room_id[$room_count]; //too assign the id of individual room element in the table
                    echo " 
                    <div class='col-lg-3 col-md-6 col-sm-6'>
                    <td id='room_table_data'>
                    <div class='card card-stats'>
                    <div class='card-header success' data-background-color=green id='$id' >
                                    
									<i class='material-icons unselectable' unselectable='on'>group</i>
								</div>
                                
                    <div class='card-content'>
                                    <h2 class='title' style='white-space:nowrap;'><b><a href='#' class='room-table-view' value='".$room_id[$room_count]."'>$block - $room_name[$room_count]</a></b></h2>
                                    <script>
											
                                    </script>
                                   
									
								</div>
                            ";//creating the room cell in the table
                                //echo $room_id[$room_count]; //echoing the room number
                                //echo "<br>"; 
                                $x=0; // this variable is for checking if there are meetings more than the threshhold. if so, show a more 
                                      //option and hide the extra part.
                                $md=$meeting_detail[$room_id[$room_count]];//get all the meeting details for the room
                                //var_dump($md);//for debugging
                                echo "	<div class='card-footer'>
									<div class='stats '>";
                                echo "<i class='material-icons text-success unselectable' id='time-icon-".$room_id[$room_count]."'>schedule</i> ";
                    
										
									            
                                foreach($md as $md1){   
                                    //for displaying all the meeting happening in the room.
                                    echo "<a href='#' class='room-card-footer-view' value='".$md1['m_id']."'>(".substr($md1['s_time'],11,5)." - ".substr($md1['e_time'],11,5).")&nbsp</a>";
                                  //echo "<script></script>";
                                    $x++;
                                    if($x>$more_option){
                                        echo "<a href='#' class='room-table-view' value='".$room_id[$room_count]."'>More</a>"; //if meeting are more than 1 display more then stop.
                                        //make the room warning if the number of meetings are more than 3.
                                        echo "<script>
                        
                                           $('#".$room_id[$room_count]."').attr('data-background-color','orange');
                       
                                            $('#".$room_id[$room_count]."').toggleClass('success');//change the class for success here
                                            $('#".$room_id[$room_count]."').toggleClass('warning'); //change the class for warning here
                                            $('#time-icon-".$room_id[$room_count]."').toggleClass('text-success'); //change the class for time icon here
                                            $('#time-icon-".$room_id[$room_count]."').toggleClass('text-danger'); //change the class for time icon here
                                            
                                            </script>";
                                      
                                        break;
                                    }// close if
                                }// close foreach
                    echo "</div>
								</div>
				                        ";
                    echo "
                        
                        </div>
                        </td>
                        </div>";//closing html tags
                    $j++;//increment column
                    if($room_count<sizeof($room_id)-1){
                        $room_count++; //increment the roomcount
                    }
                    else{
                        break; //if roomcount more than number of rooms, break.
                    }
                }//close inner while
            echo "</tr>";//close html tags
            echo "</div>";
            $i++;//increment row.
            $j=0;//rest coumn to 0.
        }//close outer while
        echo "</table>";//close table
        echo "</div>";//close div
                
        
        //end php.
        ?>
                          
                          
  <div class="modal fade" id="viewRoom" tabindex="-1" role="dialog" aria-labelledby="View Room" aria-hidden="true">
  <div class="modal-dialog" id="room-table">
    <script>
		
    </script>
  </div>
</div>
        
        
				   </div>
				   <br><br>
				   <div id="graph-tab" class="hidden">
				   </div>
				   <br>
				   <div id="calendar-tab" class="hidden" style="overflow:scroll; max-height:500px;">
					   	<div id='script-warning'>
							<code>../../Meeting_Scheduler/php/get-events.php</code> must be running.
						</div>
						<div id='loading'>loading...</div>
						<div id='calendar'></div>
				   </div>
    
    
    

         

            
            
            
           </div>
        </div>
    </div>
</body>
<!--   Core JS Files   -->

<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/material.min.js" type="text/javascript"></script>
<script src="js/bootstrap.js" type="text/javascript"></script>
<script src="js/vis.min.js"></script>
<script src="js/login-register.js" type="text/javascript"></script>
<script type="text/javascript" src="js/moment.min.js"></script>

<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>

<!--  Notifications Plugin    -->
<script src="js/bootstrap-notify.js"></script>

<!-- Material Dashboard javascript methods -->
<script src="js/material-dashboard.js"></script>
	<script src='js/fullcalendar.min.js'></script>


</html>
<?php } ?>